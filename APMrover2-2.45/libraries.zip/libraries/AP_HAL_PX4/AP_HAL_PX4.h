
#ifndef __AP_HAL_PX4_H__
#define __AP_HAL_PX4_H__

#include <AP_HAL.h>

#if CONFIG_HAL_BOARD == HAL_BOARD_PX4
#include "HAL_PX4_Class.h"
#include "AP_HAL_PX4_Main.h"

#endif // CONFIG_HAL_BOARD
#endif // __AP_HAL_PX4_H__

