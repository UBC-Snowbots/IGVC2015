/// -*- tab-width: 4; Mode: C++; c-basic-offset: 4; indent-tabs-mode: nil -*-

unsigned        memcheck_available_memory(void);
void            memcheck_init(void);
